/**
 * AI Models Catalog Component
 */
import React from 'react';
import { Boxes, CheckCircle2, Download, Zap } from 'lucide-react';
import { AiModelInfo } from '../types';

export const ModelsView: React.FC = () => {
  const models: AiModelInfo[] = [
    {
      id: 'realesrgan',
      name: 'Real-ESRGAN x4plus',
      type: 'super-resolution',
      description: 'State-of-the-art blind super-resolution for general photographic images with pristine texture recovery.',
      speed: 'Balanced',
      vram: '2.4 GB',
      supportedTypes: ['image'],
      badge: 'Recommended',
      status: 'Ready',
    },
    {
      id: 'swinir',
      name: 'SwinIR Large 8K',
      type: 'super-resolution',
      description: 'Transformer-based image restoration model achieving exceptional fidelity and sharpness for 8K exports.',
      speed: 'High Quality',
      vram: '4.5 GB',
      supportedTypes: ['image'],
      badge: 'Ultra HD',
      status: 'Ready',
    },
    {
      id: 'gfpgan',
      name: 'GFPGAN v1.4 (Face Restore)',
      type: 'face-restoration',
      description: 'Blind face restoration algorithm leveraging generative facial priors to restore blurred or low-res faces.',
      speed: 'Fast',
      vram: '1.2 GB',
      supportedTypes: ['image', 'video'],
      badge: 'Facial AI',
      status: 'Ready',
    },
    {
      id: 'codeformer',
      name: 'CodeFormer Face Predictor',
      type: 'face-restoration',
      description: 'Robust face restoration with codebook lookup transformer for high fidelity facial structure recovery.',
      speed: 'Balanced',
      vram: '2.0 GB',
      supportedTypes: ['image'],
      badge: 'Professional',
      status: 'Ready',
    },
    {
      id: 'realbasicvsr',
      name: 'RealBasicVSR++',
      type: 'video-enhancement',
      description: 'Advanced video super-resolution model with temporal consistency for smooth frame interpolation and sharpening.',
      speed: 'High Quality',
      vram: '6.0 GB',
      supportedTypes: ['video'],
      badge: '8K Video',
      status: 'Ready',
    },
  ];

  return (
    <div className="space-y-6 pb-12">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Boxes className="h-6 w-6 text-purple-400" />
          <span>AI Super-Resolution Models Catalog</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Open-source neural models integrated for local WebGPU / ONNX Runtime and cloud execution.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {models.map((model) => (
          <div key={model.id} className="rounded-3xl border border-slate-800 bg-slate-900 p-6 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="rounded-full bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-300 border border-indigo-500/25">
                  {model.badge}
                </span>
                <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
                  <CheckCircle2 className="h-4 w-4" />
                  {model.status}
                </span>
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">{model.name}</h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{model.description}</p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <div className="flex items-center gap-4">
                <span>Speed: <strong className="text-white">{model.speed}</strong></span>
                <span>VRAM: <strong className="text-white">{model.vram}</strong></span>
              </div>
              <span className="rounded bg-slate-800 px-2 py-1 text-[11px] font-mono uppercase text-slate-300">
                {model.type}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
