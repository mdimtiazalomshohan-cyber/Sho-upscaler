/**
 * Dashboard component for SHO Upscale Studio
 */
import React from 'react';
import { Sparkles, Upload, Video, Image as ImageIcon, ArrowRight, ShieldCheck, Zap, Layers, Cpu } from 'lucide-react';
import { TabType } from './Sidebar';
import { MediaItem } from '../types';

interface DashboardProps {
  setCurrentTab: (tab: TabType) => void;
  onUploadClick: (type: 'image' | 'video') => void;
  recentItems: MediaItem[];
}

export const Dashboard: React.FC<DashboardProps> = ({
  setCurrentTab,
  onUploadClick,
  recentItems,
}) => {
  return (
    <div className="space-y-8 pb-12">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 p-8 md:p-12 border border-indigo-500/20 shadow-2xl">
        <div className="absolute right-0 top-0 -mt-12 -mr-12 h-96 w-96 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"></div>
        <div className="absolute left-1/3 bottom-0 h-64 w-64 rounded-full bg-purple-500/10 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full bg-indigo-500/10 px-3.5 py-1.5 text-xs font-semibold text-indigo-300 border border-indigo-500/30">
            <Sparkles className="h-4 w-4 text-indigo-400" />
            <span>Next-Gen Super Resolution & AI Enhancement</span>
          </div>

          <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
            Upscale Images & Videos to <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400 bg-clip-text text-transparent">8K Resolution</span> with AI
          </h1>

          <p className="text-slate-300 text-base md:text-lg">
            Professional AI super-resolution suite powered by Real-ESRGAN, SwinIR & GFPGAN. Preserve natural textures, recover sharp edge details, and restore faces with zero artifacts.
          </p>

          <div className="flex flex-wrap gap-4 pt-2">
            <button
              onClick={() => setCurrentTab('image')}
              className="flex items-center gap-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-purple-500 transition-all hover:scale-[1.02]"
            >
              <ImageIcon className="h-5 w-5" />
              <span>Upscale Image Now</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              onClick={() => setCurrentTab('video')}
              className="flex items-center gap-2.5 rounded-xl bg-slate-900 px-6 py-3.5 text-sm font-semibold text-white border border-slate-700 hover:bg-slate-800 transition-all hover:scale-[1.02]"
            >
              <Video className="h-5 w-5 text-purple-400" />
              <span>Upscale Video (8K)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="rounded-2xl bg-slate-900/60 p-5 border border-slate-800/80 backdrop-blur-sm">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider">Engine Mode</span>
            <Cpu className="h-5 w-5 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white">Local WebGPU</div>
          <p className="text-xs text-emerald-400 mt-1">100% Privacy & Zero Uploads</p>
        </div>

        <div className="rounded-2xl bg-slate-900/60 p-5 border border-slate-800/80 backdrop-blur-sm">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider">Max Target</span>
            <Zap className="h-5 w-5 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white">8K UHD (7680x4320)</div>
          <p className="text-xs text-slate-400 mt-1">Up to 8X Super Resolution</p>
        </div>

        <div className="rounded-2xl bg-slate-900/60 p-5 border border-slate-800/80 backdrop-blur-sm">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider">Stock Ready</span>
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white">Enabled</div>
          <p className="text-xs text-emerald-400 mt-1">Marketplace compliant fidelity</p>
        </div>

        <div className="rounded-2xl bg-slate-900/60 p-5 border border-slate-800/80 backdrop-blur-sm">
          <div className="flex items-center justify-between text-slate-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider">Batch Processing</span>
            <Layers className="h-5 w-5 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white">Multi-File Queue</div>
          <p className="text-xs text-slate-400 mt-1">Parallel worker threads</p>
        </div>
      </div>

      {/* Quick Action Upload Boxes */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div
          onClick={() => setCurrentTab('image')}
          className="group relative cursor-pointer overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-b from-slate-900/90 to-slate-950 p-8 transition-all hover:border-indigo-500/50 hover:shadow-xl hover:shadow-indigo-500/10"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 group-hover:scale-110 transition-transform">
              <ImageIcon className="h-7 w-7" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Image Upscaler Studio</h3>
              <p className="text-sm text-slate-400">JPG, PNG, WEBP, TIFF up to 8K</p>
            </div>
          </div>
          <p className="text-sm text-slate-300 mb-6">
            Restore faces with GFPGAN, enhance details, remove noise, and upscale up to 8X without losing natural textures.
          </p>
          <div className="flex items-center text-sm font-semibold text-indigo-400 group-hover:translate-x-1 transition-transform">
            <span>Open Image Studio</span>
            <ArrowRight className="ml-2 h-4 w-4" />
          </div>
        </div>

        <div
          onClick={() => setCurrentTab('video')}
          className="group relative cursor-pointer overflow-hidden rounded-3xl border border-slate-800 bg-gradient-to-b from-slate-900/90 to-slate-950 p-8 transition-all hover:border-purple-500/50 hover:shadow-xl hover:shadow-purple-500/10"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-600/20 border border-purple-500/30 text-purple-400 group-hover:scale-110 transition-transform">
              <Video className="h-7 w-7" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Video Upscaler Studio</h3>
              <p className="text-sm text-slate-400">MP4, MOV, WEBM, MKV up to 8K</p>
            </div>
          </div>
          <p className="text-sm text-slate-300 mb-6">
            Frame-by-frame super-resolution, motion-consistent enhancement, audio preservation, and H.265/AV1 export.
          </p>
          <div className="flex items-center text-sm font-semibold text-purple-400 group-hover:translate-x-1 transition-transform">
            <span>Open Video Studio</span>
            <ArrowRight className="ml-2 h-4 w-4" />
          </div>
        </div>
      </div>

      {/* Recent Projects Section */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/40 p-6 md:p-8 backdrop-blur-sm">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-white">Recent Upscaled Projects</h3>
          <button
            onClick={() => setCurrentTab('history')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300"
          >
            View All History →
          </button>
        </div>

        {recentItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-800 py-12 text-center">
            <Upload className="h-10 w-10 text-slate-600 mb-3 animate-bounce" />
            <p className="text-sm font-medium text-slate-300">No upscaled files yet</p>
            <p className="text-xs text-slate-500 mt-1">Upload an image or video above to start your first 8K upscale.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentItems.slice(0, 3).map((item) => (
              <div key={item.id} className="rounded-2xl border border-slate-800 bg-slate-900 p-4 flex gap-4 items-center">
                <img
                  src={item.outputUrl || item.url}
                  alt={item.name}
                  className="h-16 w-16 rounded-xl object-cover border border-slate-700"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold text-white truncate">{item.name}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {item.originalWidth}x{item.originalHeight} → {item.targetWidth}x{item.targetHeight}
                  </p>
                  <span className="inline-block mt-2 rounded bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400 border border-emerald-500/20">
                    Completed
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
