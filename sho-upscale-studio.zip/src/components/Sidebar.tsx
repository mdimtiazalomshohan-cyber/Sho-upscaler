/**
 * Sidebar component for navigation
 */
import React from 'react';
import {
  LayoutDashboard,
  Image as ImageIcon,
  Video,
  ListOrdered,
  History,
  Boxes,
  KeyRound,
  Settings,
  HelpCircle,
} from 'lucide-react';

export type TabType =
  | 'dashboard'
  | 'image'
  | 'video'
  | 'batch'
  | 'history'
  | 'models'
  | 'api'
  | 'settings'
  | 'help';

interface SidebarProps {
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
  batchCount: number;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  batchCount,
  mobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'image', label: 'Image Upscaler', icon: ImageIcon },
    { id: 'video', label: 'Video Upscaler', icon: Video },
    { id: 'batch', label: 'Batch Queue', icon: ListOrdered, badge: batchCount > 0 ? batchCount : undefined },
    { id: 'history', label: 'History', icon: History },
    { id: 'models', label: 'AI Models', icon: Boxes },
    { id: 'api', label: 'API Settings', icon: KeyRound },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'help', label: 'Help & Guide', icon: HelpCircle },
  ];

  const handleTabClick = (id: string) => {
    setCurrentTab(id as TabType);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-slate-800 bg-slate-950 transition-transform duration-300 md:static md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center border-b border-slate-800 px-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Workspace Navigation</span>
        </div>

        <nav className="flex-1 space-y-1.5 px-3 py-4 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-lg shadow-indigo-600/20'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`h-5 w-5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500 text-[11px] font-bold text-slate-950">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer Hardware Status */}
        <div className="border-t border-slate-800 p-4">
          <div className="rounded-xl bg-slate-900 p-3 border border-slate-800/80">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Hardware Engine</span>
              <span className="font-semibold text-emerald-400">WebGPU / Wasm</span>
            </div>
            <div className="mt-2 h-1.5 w-full rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 w-3/4 rounded-full"></div>
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
              <span>VRAM Usage</span>
              <span>1.8 GB / 8 GB</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
