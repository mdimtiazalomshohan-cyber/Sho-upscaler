/**
 * Before/After comparison slider component with zoom & pan
 */
import React, { useState, useRef } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2 } from 'lucide-react';

interface BeforeAfterViewerProps {
  originalUrl: string;
  upscaledUrl: string;
  originalRes: string;
  upscaledRes: string;
}

export const BeforeAfterViewer: React.FC<BeforeAfterViewerProps> = ({
  originalUrl,
  upscaledUrl,
  originalRes,
  upscaledRes,
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [zoom, setZoom] = useState(1);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!containerRef.current || e.touches.length === 0) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.touches[0].clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  return (
    <div className="space-y-3">
      {/* Viewer Header Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-xs font-medium text-slate-300">
          <span className="rounded bg-slate-800 px-2.5 py-1 border border-slate-700">Original: {originalRes}</span>
          <span>vs</span>
          <span className="rounded bg-indigo-600/20 px-2.5 py-1 text-indigo-300 border border-indigo-500/30">Upscaled: {upscaledRes}</span>
        </div>

        <div className="flex items-center gap-1.5 rounded-lg bg-slate-900 p-1 border border-slate-800">
          <button
            onClick={() => setZoom((z) => Math.max(1, z - 0.25))}
            className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            title="Zoom Out"
          >
            <ZoomOut className="h-4 w-4" />
          </button>
          <span className="px-2 text-xs font-semibold text-slate-300">{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => setZoom((z) => Math.min(3, z + 0.25))}
            className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            title="Zoom In"
          >
            <ZoomIn className="h-4 w-4" />
          </button>
          <button
            onClick={() => setZoom(1)}
            className="rounded p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white"
            title="Reset Zoom"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Comparison Canvas Container */}
      <div
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseUp={() => setIsDragging(false)}
        onMouseLeave={() => setIsDragging(false)}
        onTouchMove={handleTouchMove}
        onTouchEnd={() => setIsDragging(false)}
        className="relative h-[420px] md:h-[520px] w-full overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 select-none cursor-ew-resize shadow-2xl"
      >
        <div
          className="absolute inset-0 h-full w-full overflow-hidden"
          style={{ transform: `scale(${zoom})`, transformOrigin: 'center' }}
        >
          {/* Upscaled Image (Right / Background) */}
          <img
            src={upscaledUrl}
            alt="Upscaled"
            className="absolute inset-0 h-full w-full object-contain pointer-events-none"
          />

          {/* Original Image (Left / Clipped) */}
          <div
            className="absolute inset-y-0 left-0 overflow-hidden pointer-events-none"
            style={{ width: `${sliderPosition}%` }}
          >
            <img
              src={originalUrl}
              alt="Original"
              className="absolute inset-0 h-full w-full object-contain max-w-none"
              style={{ width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%' }}
            />
          </div>

          {/* Divider Handle */}
          <div
            className="absolute inset-y-0 w-1 bg-indigo-500 shadow-[0_0_12px_rgba(99,102,241,0.8)] cursor-ew-resize z-10"
            style={{ left: `${sliderPosition}%` }}
            onMouseDown={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onTouchStart={() => setIsDragging(true)}
          >
            <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-white shadow-lg border border-indigo-400">
              <span className="text-[10px] font-bold">◄►</span>
            </div>
          </div>
        </div>

        {/* Labels Overlay */}
        <div className="absolute bottom-4 left-4 z-20 rounded-lg bg-slate-950/80 px-3 py-1.5 text-xs font-semibold text-slate-300 border border-slate-800 backdrop-blur-md pointer-events-none">
          Original
        </div>
        <div className="absolute bottom-4 right-4 z-20 rounded-lg bg-indigo-950/80 px-3 py-1.5 text-xs font-semibold text-indigo-300 border border-indigo-500/30 backdrop-blur-md pointer-events-none">
          AI Upscaled (8K)
        </div>
      </div>
    </div>
  );
};
