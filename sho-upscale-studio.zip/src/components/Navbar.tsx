/**
 * Navbar component for SHO Upscale Studio
 */
import React from 'react';
import { Sparkles, Cpu, Cloud, ShieldAlert, Zap, Menu } from 'lucide-react';
import { ProcessingMode } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  processingMode: ProcessingMode;
  setProcessingMode: (mode: ProcessingMode) => void;
  activeJobsCount: number;
  onOpenBatch: () => void;
  onToggleMobileMenu: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  processingMode,
  setProcessingMode,
  activeJobsCount,
  onOpenBatch,
  onToggleMobileMenu,
}) => {
  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-slate-800 bg-slate-950/80 px-4 md:px-6 backdrop-blur-md">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobileMenu}
          className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white md:hidden"
          aria-label="Toggle menu"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 via-slate-900 to-purple-900 shadow-lg shadow-indigo-500/30 border border-indigo-500/40 overflow-hidden p-1">
            {/* Custom Stylized Raccoon Logo matching user upload */}
            <svg viewBox="0 0 100 100" className="h-full w-full fill-white">
              <path d="M50 15 C55 25 70 28 82 22 L75 38 C85 45 88 58 80 72 L65 65 C68 75 60 85 50 88 C40 85 32 75 35 65 L20 72 C12 58 15 45 25 38 L18 22 C30 28 45 25 50 15 Z" fill="#0f172a" stroke="#6366f1" strokeWidth="4" />
              {/* Ears inner */}
              <polygon points="23,28 32,40 28,15" fill="#6366f1" opacity="0.8" />
              <polygon points="77,28 68,40 72,15" fill="#6366f1" opacity="0.8" />
              {/* White Mask / Eyes area */}
              <path d="M25 45 C35 40 45 52 50 55 C55 52 65 40 75 45 C78 55 70 65 50 60 C30 65 22 55 25 45 Z" fill="#ffffff" />
              {/* Eyes */}
              <ellipse cx="38" cy="50" rx="4" ry="6" fill="#0f172a" transform="rotate(-15 38 50)" />
              <ellipse cx="62" cy="50" rx="4" ry="6" fill="#0f172a" transform="rotate(15 62 50)" />
              {/* Nose */}
              <path d="M46 62 Q50 58 54 62 Q52 70 50 72 Q48 70 46 62 Z" fill="#0f172a" />
              {/* Mouth / Chin */}
              <path d="M42 76 Q50 80 58 76" stroke="#0f172a" strokeWidth="3" strokeLinecap="round" fill="none" />
              {/* Bowtie */}
              <polygon points="50,82 40,92 46,95 50,88" fill="#6366f1" />
              <polygon points="50,82 60,92 54,95 50,88" fill="#6366f1" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-wider text-white text-lg">SHO <span className="bg-gradient-to-r from-indigo-400 to-pink-400 bg-clip-text text-transparent">UPSCALE STUDIO</span></span>
              <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-300 border border-indigo-500/30">8K PRO</span>
            </div>
            <p className="hidden text-xs text-slate-400 sm:block">AI Image & Video Super-Resolution Suite</p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-4">
        {/* Processing Mode Switcher */}
        <div className="flex items-center rounded-lg bg-slate-900 p-1 border border-slate-800">
          <button
            onClick={() => setProcessingMode('local')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
              processingMode === 'local'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Local AI</span>
          </button>
          <button
            onClick={() => setProcessingMode('cloud')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
              processingMode === 'cloud'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cloud className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Cloud AI</span>
          </button>
        </div>

        {/* Batch Queue Button */}
        <button
          onClick={onOpenBatch}
          className="relative flex items-center gap-2 rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-300 border border-slate-800 hover:bg-slate-800 hover:text-white transition-colors"
        >
          <Zap className="h-4 w-4 text-amber-400" />
          <span className="hidden sm:inline">Batch Queue</span>
          {activeJobsCount > 0 && (
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-indigo-500 text-[10px] font-bold text-white">
              {activeJobsCount}
            </span>
          )}
        </button>

        {/* PWA Install Button */}
        <PWAInstallButton />

        {/* Privacy Mode Badge */}
        <div className="hidden lg:flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs text-emerald-400 border border-emerald-500/20">
          <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>{processingMode === 'local' ? 'Privacy Protected (On-Device)' : 'Cloud API Connected'}</span>
        </div>
      </div>
    </header>
  );
};
