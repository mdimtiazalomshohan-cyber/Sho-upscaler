/**
 * Settings Component
 */
import React from 'react';
import { Settings as SettingsIcon, Cpu, Globe, Shield } from 'lucide-react';
import { AppSettings, ProcessingMode } from '../types';

interface SettingsViewProps {
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ settings, setSettings }) => {
  return (
    <div className="max-w-3xl space-y-6 pb-12">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <SettingsIcon className="h-6 w-6 text-indigo-400" />
          <span>Application Settings</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">Configure default upscaling parameters, hardware acceleration, and privacy.</p>
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-6">
        <div className="flex items-center justify-between py-3 border-b border-slate-800">
          <div>
            <h4 className="text-sm font-semibold text-white">Default Processing Mode</h4>
            <p className="text-xs text-slate-400">Choose between local WebGPU and Cloud API.</p>
          </div>
          <select
            value={settings.processingMode}
            onChange={(e) => setSettings({ ...settings, processingMode: e.target.value as ProcessingMode })}
            className="rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-white"
          >
            <option value="local">Local AI (On-Device)</option>
            <option value="cloud">Cloud AI</option>
          </select>
        </div>

        <div className="flex items-center justify-between py-3 border-b border-slate-800">
          <div>
            <h4 className="text-sm font-semibold text-white">Hardware Acceleration</h4>
            <p className="text-xs text-slate-400">Leverage WebGPU and Wasm multithreading.</p>
          </div>
          <input
            type="checkbox"
            checked={settings.hardwareAcceleration}
            onChange={(e) => setSettings({ ...settings, hardwareAcceleration: e.target.checked })}
            className="h-4 w-4 rounded border-slate-700 bg-slate-950 text-indigo-600 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-between py-3 border-b border-slate-800">
          <div>
            <h4 className="text-sm font-semibold text-white">Preserve Metadata</h4>
            <p className="text-xs text-slate-400">Keep original EXIF, color profiles, and timestamps.</p>
          </div>
          <input
            type="checkbox"
            checked={settings.preserveMetadata}
            onChange={(e) => setSettings({ ...settings, preserveMetadata: e.target.checked })}
            className="h-4 w-4 rounded border-slate-700 bg-slate-950 text-indigo-600 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-between py-3">
          <div>
            <h4 className="text-sm font-semibold text-white">Maximum Concurrent Jobs</h4>
            <p className="text-xs text-slate-400">Number of files processed simultaneously in batch.</p>
          </div>
          <select
            value={settings.maxConcurrentJobs}
            onChange={(e) => setSettings({ ...settings, maxConcurrentJobs: Number(e.target.value) })}
            className="rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-white"
          >
            <option value={1}>1 Job</option>
            <option value={2}>2 Jobs</option>
            <option value={4}>4 Jobs (Recommended)</option>
            <option value={8}>8 Jobs (High RAM)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
