/**
 * PWA Install Button & Mobile APK Guide Component
 */
import React, { useState } from 'react';
import { Download, Smartphone, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return (
      <div className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs text-emerald-400 border border-emerald-500/20">
        <CheckCircle2 className="h-3.5 w-3.5" />
        <span>PWA Installed</span>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={async () => {
          if (isInstallable) {
            await install();
          } else {
            setShowGuide(true);
          }
        }}
        className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg shadow-indigo-600/25 hover:from-indigo-500 hover:to-purple-500 transition-all"
        title="Install as Mobile App / APK"
      >
        <Smartphone className="h-4 w-4" />
        <span className="hidden sm:inline">Install App / APK</span>
      </button>

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Smartphone className="h-5 w-5 text-indigo-400" />
                <span>Install SHO Upscale Studio (Mobile & APK)</span>
              </h3>
              <button
                onClick={() => setShowGuide(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 space-y-2">
                <h4 className="font-semibold text-white">Android (Chrome / Edge / Firefox):</h4>
                <p>1. Tap the browser menu (3 dots top right).</p>
                <p>2. Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</p>
                <p>3. To wrap as a standalone APK, use free tools like <a href="https://pwabuilder.com" target="_blank" rel="noreferrer" className="text-indigo-400 underline">PWABuilder.com</a> with this app's URL.</p>
              </div>

              {isIOS && (
                <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 space-y-2">
                  <h4 className="font-semibold text-white">iOS Safari (iPhone / iPad):</h4>
                  <p>1. Tap the <strong>Share</strong> button in the Safari toolbar.</p>
                  <p>2. Scroll down and tap <strong>"Add to Home Screen"</strong>.</p>
                </div>
              )}
            </div>

            <button
              onClick={() => setShowGuide(false)}
              className="w-full rounded-xl bg-indigo-600 py-3 text-xs font-semibold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-colors"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </>
  );
};
