/**
 * Image Upscaler Studio Component
 */
import React, { useState, useRef } from 'react';
import { Upload, Sliders, Sparkles, Download, RefreshCw, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';
import { MediaItem, ScaleFactor, TargetResolution, QualitySettings, ProcessingMode } from '../types';
import { aiEngine } from '../services/aiEngine';
import { BeforeAfterViewer } from './BeforeAfterViewer';

interface ImageUpscalerProps {
  processingMode: ProcessingMode;
  onAddToBatch: (item: MediaItem) => void;
  onSaveHistory: (item: MediaItem) => void;
}

export const ImageUpscaler: React.FC<ImageUpscalerProps> = ({
  processingMode,
  onAddToBatch,
  onSaveHistory,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [originalWidth, setOriginalWidth] = useState<number>(1920);
  const [originalHeight, setOriginalHeight] = useState<number>(1080);
  const [scale, setScale] = useState<ScaleFactor>('4x');
  const [targetResolution, setTargetResolution] = useState<TargetResolution>('4K');
  const [customWidth, setCustomWidth] = useState<number>(3840);
  const [customHeight, setCustomHeight] = useState<number>(2160);

  const [quality, setQuality] = useState<QualitySettings>({
    aiStrength: 'high',
    detail: 'high',
    noiseReduction: 'medium',
    sharpen: 'medium',
    faceRestoration: 'auto',
    artifactRemoval: 'auto',
    colorEnhancement: true,
    lowLightEnhancement: false,
    stockReady: false,
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');
  const [resultItem, setResultItem] = useState<MediaItem | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      const firstFile = files[0];
      processLoadedFile(firstFile);

      if (files.length > 1) {
        files.forEach((file, index) => {
          const url = URL.createObjectURL(file);
          const newItem: MediaItem = {
            id: 'batch_img_' + Date.now() + '_' + index,
            name: file.name,
            type: 'image',
            url,
            originalWidth: 1920,
            originalHeight: 1080,
            targetWidth: customWidth,
            targetHeight: customHeight,
            originalSize: file.size,
            scale,
            targetResolution,
            quality,
            status: 'waiting',
            progress: 0,
            createdAt: Date.now(),
          };
          onAddToBatch(newItem);
        });
        alert(`Successfully added ${files.length} images to the Batch Queue!`);
      }
    }
  };

  const processLoadedFile = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);

    const img = new Image();
    img.onload = () => {
      setOriginalWidth(img.width);
      setOriginalHeight(img.height);
      updateTargetResolution(targetResolution, img.width, img.height, scale);
    };
    img.src = url;
    setResultItem(null);
  };

  const updateTargetResolution = (res: TargetResolution, w: number, h: number, currentScale: ScaleFactor) => {
    setTargetResolution(res);
    let factor = 2;
    if (currentScale === '4x') factor = 4;
    if (currentScale === '6x') factor = 6;
    if (currentScale === '8x') factor = 8;

    if (res === 'Original') {
      setCustomWidth(w);
      setCustomHeight(h);
    } else if (res === '1080p') {
      setCustomWidth(1920);
      setCustomHeight(1080);
    } else if (res === '1440p') {
      setCustomWidth(2560);
      setCustomHeight(1440);
    } else if (res === '2K') {
      setCustomWidth(2048);
      setCustomHeight(1080);
    } else if (res === '4K') {
      setCustomWidth(3840);
      setCustomHeight(2160);
    } else if (res === '6K') {
      setCustomWidth(6016);
      setCustomHeight(3384);
    } else if (res === '8K') {
      setCustomWidth(7680);
      setCustomHeight(4320);
    } else {
      setCustomWidth(w * factor);
      setCustomHeight(h * factor);
    }
  };

  const handleStartUpscale = async () => {
    if (!selectedFile || !previewUrl) return;

    setIsProcessing(true);
    setProgress(0);
    setStatusText('Initializing AI Upscale Engine...');

    const newItem: MediaItem = {
      id: 'img_' + Date.now(),
      name: selectedFile.name,
      type: 'image',
      url: previewUrl,
      originalWidth,
      originalHeight,
      targetWidth: customWidth,
      targetHeight: customHeight,
      originalSize: selectedFile.size,
      scale,
      targetResolution,
      quality,
      status: 'processing',
      progress: 0,
      createdAt: Date.now(),
    };

    try {
      const res = await aiEngine.upscaleImage(newItem, quality, (p, text) => {
        setProgress(p);
        setStatusText(text);
      });

      const completedItem: MediaItem = {
        ...newItem,
        status: 'completed',
        progress: 100,
        outputUrl: res.outputUrl,
        outputSize: res.outputSize,
        processingTime: res.processingTime,
      };

      setResultItem(completedItem);
      onSaveHistory(completedItem);
    } catch (err: any) {
      alert('Upscaling error: ' + (err.message || 'Unknown error'));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQueueBatch = () => {
    if (!selectedFile || !previewUrl) return;
    const newItem: MediaItem = {
      id: 'batch_' + Date.now(),
      name: selectedFile.name,
      type: 'image',
      url: previewUrl,
      originalWidth,
      originalHeight,
      targetWidth: customWidth,
      targetHeight: customHeight,
      originalSize: selectedFile.size,
      scale,
      targetResolution,
      quality,
      status: 'waiting',
      progress: 0,
      createdAt: Date.now(),
    };
    onAddToBatch(newItem);
    alert('Added successfully to Batch Queue!');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12">
      {/* Left 2 Cols: Preview & Upload / Result Viewer */}
      <div className="lg:col-span-2 space-y-6">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-indigo-400" />
              <span>Image Upscale Studio</span>
            </h2>
            {selectedFile && (
              <button
                onClick={() => {
                  setSelectedFile(null);
                  setPreviewUrl(null);
                  setResultItem(null);
                }}
                className="text-xs text-slate-400 hover:text-white"
              >
                Upload Different Image
              </button>
            )}
          </div>

          {!selectedFile ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="group flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-700/80 bg-slate-950/50 p-12 text-center cursor-pointer hover:border-indigo-500 hover:bg-slate-900/50 transition-all"
            >
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 mb-4 group-hover:scale-110 transition-transform">
                <Upload className="h-8 w-8" />
              </div>
              <p className="text-base font-semibold text-white">Drag & Drop your image here</p>
              <p className="text-xs text-slate-400 mt-1">Supports JPG, PNG, WEBP, TIFF up to 100MB</p>
              <button className="mt-5 rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-colors">
                Browse Files
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp,image/tiff"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : resultItem && resultItem.outputUrl ? (
            <div className="space-y-4">
              <BeforeAfterViewer
                originalUrl={previewUrl!}
                upscaledUrl={resultItem.outputUrl}
                originalRes={`${originalWidth} × ${originalHeight}`}
                upscaledRes={`${customWidth} × ${customHeight}`}
              />
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <div className="text-xs text-slate-400">
                  Processing Time: <span className="font-semibold text-white">{resultItem.processingTime}s</span> | Output Size:{' '}
                  <span className="font-semibold text-white">
                    {Math.round((resultItem.outputSize || 0) / 1024 / 1024 * 100) / 100} MB
                  </span>
                </div>
                <a
                  href={resultItem.outputUrl}
                  download={`upscaled_${selectedFile.name}`}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-emerald-600/30 hover:from-emerald-500 hover:to-teal-500 transition-all"
                >
                  <Download className="h-4 w-4" />
                  <span>Download 8K Result</span>
                </a>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative h-96 w-full rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center">
                <img src={previewUrl!} alt="Preview" className="h-full w-full object-contain" />
              </div>

              <div className="flex items-center justify-between rounded-xl bg-slate-900 p-4 border border-slate-800">
                <div>
                  <h4 className="text-sm font-semibold text-white">{selectedFile.name}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Original Resolution: {originalWidth} × {originalHeight} px ({Math.round(selectedFile.size / 1024)} KB)
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Target Resolution:</span>
                  <div className="text-sm font-bold text-indigo-400">
                    {customWidth} × {customHeight} px ({targetResolution})
                  </div>
                </div>
              </div>

              {isProcessing && (
                <div className="rounded-2xl bg-indigo-950/40 p-5 border border-indigo-500/30 space-y-3">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-indigo-300 flex items-center gap-2">
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      {statusText}
                    </span>
                    <span className="text-indigo-400">{progress}%</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-300 rounded-full"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right Col: Scaling & Quality Controls */}
      <div className="space-y-6">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="h-4 w-4 text-indigo-400" />
            <span>Upscale Configuration</span>
          </h3>

          {/* Scale Factor */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Upscale Factor</label>
            <div className="grid grid-cols-4 gap-2">
              {(['2x', '4x', '6x', '8x'] as ScaleFactor[]).map((s) => (
                <button
                  key={s}
                  onClick={() => {
                    setScale(s);
                    updateTargetResolution(targetResolution, originalWidth, originalHeight, s);
                  }}
                  className={`rounded-xl py-2.5 text-xs font-bold transition-all ${
                    scale === s
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {s.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Target Resolution */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Target Resolution</label>
            <select
              value={targetResolution}
              onChange={(e) => updateTargetResolution(e.target.value as TargetResolution, originalWidth, originalHeight, scale)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-medium text-white focus:border-indigo-500 focus:outline-none"
            >
              <option value="Original">Original Resolution</option>
              <option value="1080p">1080p Full HD (1920x1080)</option>
              <option value="1440p">1440p QHD (2560x1440)</option>
              <option value="2K">2K Cinema (2048x1080)</option>
              <option value="4K">4K UHD (3840x2160)</option>
              <option value="6K">6K Ultra (6016x3384)</option>
              <option value="8K">8K UHD (7680x4320)</option>
            </select>
          </div>

          {/* Quality Controls */}
          <div className="space-y-4 pt-2 border-t border-slate-800">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">AI Enhancement Settings</h4>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">AI Strength</span>
                <span className="text-indigo-400 font-semibold uppercase">{quality.aiStrength}</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {(['low', 'medium', 'high', 'ultra'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setQuality({ ...quality, aiStrength: lvl })}
                    className={`rounded-lg py-1.5 text-[11px] font-medium capitalize ${
                      quality.aiStrength === lvl
                        ? 'bg-purple-600 text-white'
                        : 'bg-slate-950 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">Sharpen</label>
                <select
                  value={quality.sharpen}
                  onChange={(e) => setQuality({ ...quality, sharpen: e.target.value as any })}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-2 text-xs text-white"
                >
                  <option value="off">Off</option>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">Face Restoration</label>
                <select
                  value={quality.faceRestoration}
                  onChange={(e) => setQuality({ ...quality, faceRestoration: e.target.value as any })}
                  className="w-full rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-2 text-xs text-white"
                >
                  <option value="off">Off</option>
                  <option value="auto">Auto (GFPGAN)</option>
                  <option value="strong">Strong</option>
                </select>
              </div>
            </div>

            {/* Stock Ready Workflow Option */}
            <div className="rounded-2xl bg-indigo-950/30 p-3.5 border border-indigo-500/20 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-indigo-400" />
                  <span className="text-xs font-bold text-white">Stock Ready Workflow</span>
                </div>
                <input
                  type="checkbox"
                  checked={quality.stockReady}
                  onChange={(e) => setQuality({ ...quality, stockReady: e.target.checked })}
                  className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                />
              </div>
              <p className="text-[11px] text-slate-400">
                Preserves clean textures, prevents halos, oversmoothing, and artificial sharpening for stock photography marketplaces.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <button
              onClick={handleStartUpscale}
              disabled={!selectedFile || isProcessing}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 transition-all"
            >
              <Sparkles className="h-4 w-4" />
              <span>{isProcessing ? 'Processing 8K Upscale...' : 'Start 8K AI Upscale'}</span>
            </button>

            <button
              onClick={handleQueueBatch}
              disabled={!selectedFile}
              className="w-full rounded-2xl bg-slate-900 py-3 text-xs font-semibold text-slate-300 border border-slate-700 hover:bg-slate-800 hover:text-white disabled:opacity-50 transition-colors"
            >
              Add to Batch Queue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
