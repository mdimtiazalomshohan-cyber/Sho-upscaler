/**
 * History View Component
 */
import React from 'react';
import { History as HistoryIcon, Trash2, Download, ExternalLink } from 'lucide-react';
import { MediaItem } from '../types';

interface HistoryViewProps {
  history: MediaItem[];
  onClearHistory: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({ history, onClearHistory }) => {
  return (
    <div className="space-y-6 pb-12">
      <div className="flex items-center justify-between rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <HistoryIcon className="h-6 w-6 text-indigo-400" />
            <span>Processing History</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Review and download past upscaled images and videos</p>
        </div>
        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2.5 text-xs font-semibold text-rose-400 hover:bg-slate-700 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-3xl border border-slate-800 bg-slate-950 p-16 text-center">
          <HistoryIcon className="h-12 w-12 text-slate-600 mb-3" />
          <p className="text-base font-semibold text-white">No history records found</p>
          <p className="text-xs text-slate-500 mt-1">Completed upscales will appear here automatically.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {history.map((item) => (
            <div key={item.id} className="rounded-2xl border border-slate-800 bg-slate-900 overflow-hidden flex flex-col">
              <div className="relative h-48 w-full bg-slate-950">
                <img src={item.outputUrl || item.url} alt={item.name} className="h-full w-full object-cover" />
                <span className="absolute top-3 left-3 rounded-md bg-slate-950/80 px-2 py-1 text-[10px] font-semibold text-white border border-slate-700 backdrop-blur-md uppercase">
                  {item.type}
                </span>
              </div>
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h4 className="text-sm font-bold text-white truncate">{item.name}</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    {item.originalWidth}x{item.originalHeight} → <span className="text-indigo-400 font-semibold">{item.targetWidth}x{item.targetHeight}</span>
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Date: {new Date(item.createdAt).toLocaleDateString()} • Scale: {item.scale.toUpperCase()}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <span className="text-[11px] text-emerald-400 font-medium">Successfully Upscaled</span>
                  {item.outputUrl && (
                    <a
                      href={item.outputUrl}
                      download={`upscaled_${item.name}`}
                      className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Download</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
