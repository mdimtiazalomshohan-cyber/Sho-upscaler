/**
 * Video Upscaler Studio Component
 */
import React, { useState, useRef } from 'react';
import { Upload, Video as VideoIcon, Sliders, Sparkles, Download, RefreshCw, Film } from 'lucide-react';
import { MediaItem, ScaleFactor, TargetResolution, QualitySettings, ProcessingMode } from '../types';
import { aiEngine } from '../services/aiEngine';

interface VideoUpscalerProps {
  processingMode: ProcessingMode;
  onAddToBatch: (item: MediaItem) => void;
  onSaveHistory: (item: MediaItem) => void;
}

export const VideoUpscaler: React.FC<VideoUpscalerProps> = ({
  processingMode,
  onAddToBatch,
  onSaveHistory,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [originalWidth, setOriginalWidth] = useState<number>(1920);
  const [originalHeight, setOriginalHeight] = useState<number>(1080);
  const [scale, setScale] = useState<ScaleFactor>('2x');
  const [targetResolution, setTargetResolution] = useState<TargetResolution>('4K');
  const [codec, setCodec] = useState<string>('H.265');
  const [customWidth, setCustomWidth] = useState<number>(3840);
  const [customHeight, setCustomHeight] = useState<number>(2160);

  const [quality, setQuality] = useState<QualitySettings>({
    aiStrength: 'high',
    detail: 'high',
    noiseReduction: 'medium',
    sharpen: 'medium',
    faceRestoration: 'auto',
    artifactRemoval: 'auto',
    colorEnhancement: true,
    lowLightEnhancement: false,
    stockReady: false,
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');
  const [resultItem, setResultItem] = useState<MediaItem | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      const firstFile = files[0];
      setSelectedFile(firstFile);
      const url = URL.createObjectURL(firstFile);
      setPreviewUrl(url);

      const vid = document.createElement('video');
      vid.onloadedmetadata = () => {
        setOriginalWidth(vid.videoWidth || 1920);
        setOriginalHeight(vid.videoHeight || 1080);
        setCustomWidth((vid.videoWidth || 1920) * 2);
        setCustomHeight((vid.videoHeight || 1080) * 2);
      };
      vid.src = url;
      setResultItem(null);

      if (files.length > 1) {
        files.forEach((file, index) => {
          const vUrl = URL.createObjectURL(file);
          const newItem: MediaItem = {
            id: 'batch_vid_' + Date.now() + '_' + index,
            name: file.name,
            type: 'video',
            url: vUrl,
            originalWidth: 1920,
            originalHeight: 1080,
            targetWidth: customWidth,
            targetHeight: customHeight,
            originalSize: file.size,
            scale,
            targetResolution,
            quality,
            status: 'waiting',
            progress: 0,
            createdAt: Date.now(),
            codec,
          };
          onAddToBatch(newItem);
        });
        alert(`Successfully added ${files.length} videos to the Batch Queue!`);
      }
    }
  };

  const handleStartUpscale = async () => {
    if (!selectedFile || !previewUrl) return;

    setIsProcessing(true);
    setProgress(0);
    setStatusText('Initializing Video Super-Resolution Pipeline...');

    const newItem: MediaItem = {
      id: 'vid_' + Date.now(),
      name: selectedFile.name,
      type: 'video',
      url: previewUrl,
      originalWidth,
      originalHeight,
      targetWidth: customWidth,
      targetHeight: customHeight,
      originalSize: selectedFile.size,
      scale,
      targetResolution,
      quality,
      status: 'processing',
      progress: 0,
      createdAt: Date.now(),
      codec,
      fps: 30,
    };

    try {
      const res = await aiEngine.upscaleVideo(newItem, quality, (p, text) => {
        setProgress(p);
        setStatusText(text);
      });

      const completedItem: MediaItem = {
        ...newItem,
        status: 'completed',
        progress: 100,
        outputUrl: res.outputUrl,
        outputSize: res.outputSize,
        processingTime: res.processingTime,
      };

      setResultItem(completedItem);
      onSaveHistory(completedItem);
    } catch (err: any) {
      alert('Video upscaling error: ' + (err.message || 'Unknown error'));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQueueBatch = () => {
    if (!selectedFile || !previewUrl) return;
    const newItem: MediaItem = {
      id: 'batch_vid_' + Date.now(),
      name: selectedFile.name,
      type: 'video',
      url: previewUrl,
      originalWidth,
      originalHeight,
      targetWidth: customWidth,
      targetHeight: customHeight,
      originalSize: selectedFile.size,
      scale,
      targetResolution,
      quality,
      status: 'waiting',
      progress: 0,
      createdAt: Date.now(),
      codec,
    };
    onAddToBatch(newItem);
    alert('Video added successfully to Batch Queue!');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12">
      <div className="lg:col-span-2 space-y-6">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Film className="h-5 w-5 text-purple-400" />
              <span>Video Upscaler Studio (Up to 8K)</span>
            </h2>
            {selectedFile && (
              <button
                onClick={() => {
                  setSelectedFile(null);
                  setPreviewUrl(null);
                  setResultItem(null);
                }}
                className="text-xs text-slate-400 hover:text-white"
              >
                Upload Different Video
              </button>
            )}
          </div>

          {!selectedFile ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="group flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-700/80 bg-slate-950/50 p-12 text-center cursor-pointer hover:border-purple-500 hover:bg-slate-900/50 transition-all"
            >
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-purple-600/10 border border-purple-500/20 text-purple-400 mb-4 group-hover:scale-110 transition-transform">
                <VideoIcon className="h-8 w-8" />
              </div>
              <p className="text-base font-semibold text-white">Drag & Drop your video file here</p>
              <p className="text-xs text-slate-400 mt-1">Supports MP4, MOV, WEBM, MKV, AVI up to 2GB</p>
              <button className="mt-5 rounded-xl bg-purple-600 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-purple-600/30 hover:bg-purple-500 transition-colors">
                Browse Videos
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="video/mp4,video/quicktime,video/webm,video/x-matroska,video/x-msvideo"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative h-96 w-full rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 flex items-center justify-center">
                <video src={previewUrl!} controls className="h-full w-full object-contain" />
              </div>

              <div className="flex items-center justify-between rounded-xl bg-slate-900 p-4 border border-slate-800">
                <div>
                  <h4 className="text-sm font-semibold text-white">{selectedFile.name}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Original Resolution: {originalWidth} × {originalHeight} px ({Math.round(selectedFile.size / 1024 / 1024 * 10) / 10} MB)
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Target Output:</span>
                  <div className="text-sm font-bold text-purple-400">
                    {customWidth} × {customHeight} px ({codec})
                  </div>
                </div>
              </div>

              {isProcessing && (
                <div className="rounded-2xl bg-purple-950/40 p-5 border border-purple-500/30 space-y-3">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-purple-300 flex items-center gap-2">
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      {statusText}
                    </span>
                    <span className="text-purple-400">{progress}%</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-indigo-500 transition-all duration-300 rounded-full"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              {resultItem && resultItem.outputUrl && (
                <div className="rounded-2xl bg-emerald-950/30 p-5 border border-emerald-500/30 flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-emerald-300">Video Upscaling Complete!</h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Processing Time: {resultItem.processingTime}s | Codec: {codec}
                    </p>
                  </div>
                  <a
                    href={resultItem.outputUrl}
                    download={`upscaled_${selectedFile.name}`}
                    className="flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-emerald-600/30 hover:bg-emerald-500 transition-all"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Video</span>
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="space-y-6">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm space-y-6">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="h-4 w-4 text-purple-400" />
            <span>Video Pipeline Options</span>
          </h3>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Upscale Factor</label>
            <div className="grid grid-cols-3 gap-2">
              {(['2x', '4x', '8x'] as ScaleFactor[]).map((s) => (
                <button
                  key={s}
                  onClick={() => setScale(s)}
                  className={`rounded-xl py-2.5 text-xs font-bold transition-all ${
                    scale === s
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                  }`}
                >
                  {s.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Target Resolution</label>
            <select
              value={targetResolution}
              onChange={(e) => setTargetResolution(e.target.value as TargetResolution)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-medium text-white focus:border-purple-500 focus:outline-none"
            >
              <option value="1080p">1080p Full HD</option>
              <option value="1440p">1440p QHD</option>
              <option value="2K">2K Cinema</option>
              <option value="4K">4K UHD (3840x2160)</option>
              <option value="6K">6K Ultra</option>
              <option value="8K">8K UHD (7680x4320)</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Video Codec</label>
            <select
              value={codec}
              onChange={(e) => setCodec(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-medium text-white focus:border-purple-500 focus:outline-none"
            >
              <option value="H.264">H.264 / AVC (Standard)</option>
              <option value="H.265">H.265 / HEVC (High Efficiency)</option>
              <option value="AV1">AV1 (Next-Gen Ultra)</option>
            </select>
          </div>

          <div className="space-y-4 pt-2 border-t border-slate-800">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Video Enhancement</h4>

            <div className="space-y-1">
              <label className="text-[11px] text-slate-400">Frame Denoise</label>
              <select
                value={quality.noiseReduction}
                onChange={(e) => setQuality({ ...quality, noiseReduction: e.target.value as any })}
                className="w-full rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-2 text-xs text-white"
              >
                <option value="off">Off</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t border-slate-800">
            <button
              onClick={handleStartUpscale}
              disabled={!selectedFile || isProcessing}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-3.5 text-sm font-bold text-white shadow-lg shadow-purple-600/30 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50 transition-all"
            >
              <Sparkles className="h-4 w-4" />
              <span>{isProcessing ? 'Processing Video 8K...' : 'Start Video 8K Upscale'}</span>
            </button>

            <button
              onClick={handleQueueBatch}
              disabled={!selectedFile}
              className="w-full rounded-2xl bg-slate-900 py-3 text-xs font-semibold text-slate-300 border border-slate-700 hover:bg-slate-800 hover:text-white disabled:opacity-50 transition-colors"
            >
              Add Video to Batch Queue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
