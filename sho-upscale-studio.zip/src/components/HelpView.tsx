/**
 * Help & Guide Component
 */
import React from 'react';
import { HelpCircle, ShieldCheck, Zap, Sparkles } from 'lucide-react';

export const HelpView: React.FC = () => {
  return (
    <div className="max-w-4xl space-y-8 pb-12">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <HelpCircle className="h-6 w-6 text-indigo-400" />
          <span>Help, Documentation & 8K Guide</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">Everything you need to know about upscaling images and videos to 4K and 8K.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-indigo-400" />
            <span>How to Enable 4K & 8K Upscaling</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Select <strong>4K UHD</strong> (3840x2160) or <strong>8K UHD</strong> (7680x4320) in the Target Resolution dropdown within the Image or Video Upscaler studio. For optimal results on lower-res sources (e.g. 1080p), use a 4X or 8X scale factor with <strong>SwinIR</strong> or <strong>Real-ESRGAN</strong> models.
          </p>
        </div>

        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
            <span>Stock Content Workflow</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Enable the <strong>Stock Ready</strong> option when preparing images for stock photo marketplaces. This workflow prevents over-sharpening halos, artificial noise, and excessive smoothing, keeping textures natural and pristine.
          </p>
          <p className="text-[11px] text-amber-400/90 font-medium">
            *Note: Upscaling does not guarantee acceptance by stock marketplaces. Source quality is crucial.
          </p>
        </div>

        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-amber-400" />
            <span>Local AI vs Cloud AI</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            <strong>Local AI</strong> runs directly in your browser using WebGPU and Canvas algorithms, guaranteeing 100% data privacy with zero server uploads. <strong>Cloud AI</strong> utilizes high-performance server models for extreme workloads.
          </p>
        </div>

        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-purple-400" />
            <span>Troubleshooting Memory Limits</span>
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Processing 8K video files locally requires high browser memory. If you encounter memory errors, try processing shorter video segments, reducing concurrent queue jobs in Settings, or switching to Cloud AI.
          </p>
        </div>
      </div>
    </div>
  );
};
