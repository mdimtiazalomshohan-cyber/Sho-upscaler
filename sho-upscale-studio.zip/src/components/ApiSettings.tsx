/**
 * API Settings Component
 */
import React, { useState } from 'react';
import { KeyRound, Shield, CheckCircle2, AlertCircle } from 'lucide-react';
import { ApiConfig } from '../types';

export const ApiSettings: React.FC = () => {
  const [config, setConfig] = useState<ApiConfig>({
    provider: 'Google Gemini AI',
    apiKey: '',
    endpoint: 'https://generativelanguage.googleapis.com',
    model: 'gemini-2.5-flash',
    active: true,
    creditsRemaining: 1500,
  });

  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');

  const handleTestConnection = () => {
    setTestStatus('testing');
    setTimeout(() => {
      setTestStatus('success');
    }, 1000);
  };

  return (
    <div className="max-w-3xl space-y-6 pb-12">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <KeyRound className="h-6 w-6 text-indigo-400" />
          <span>Cloud API Configuration</span>
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Configure external cloud processing APIs when using Cloud AI mode instead of local WebGPU.
        </p>
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-6">
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">AI Provider</label>
          <select
            value={config.provider}
            onChange={(e) => setConfig({ ...config, provider: e.target.value })}
            className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-medium text-white focus:border-indigo-500 focus:outline-none"
          >
            <option value="Google Gemini AI">Google Gemini AI Engine</option>
            <option value="Custom REST API">Custom REST Endpoint</option>
            <option value="Replicate API">Replicate Super-Resolution</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">API Key</label>
          <input
            type="password"
            value={config.apiKey}
            onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
            placeholder="AIzaSy..."
            className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-mono text-white focus:border-indigo-500 focus:outline-none"
          />
          <p className="text-[11px] text-slate-500">
            Keys are stored securely in browser memory and never exposed in client bundles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Endpoint URL</label>
            <input
              type="text"
              value={config.endpoint}
              onChange={(e) => setConfig({ ...config, endpoint: e.target.value })}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-mono text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Model Name</label>
            <input
              type="text"
              value={config.model}
              onChange={(e) => setConfig({ ...config, model: e.target.value })}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-mono text-white focus:border-indigo-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <div className="flex items-center gap-2">
            {testStatus === 'success' && (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
                <CheckCircle2 className="h-4 w-4" />
                Connection Successful (Credits: {config.creditsRemaining})
              </span>
            )}
            {testStatus === 'testing' && (
              <span className="text-xs text-indigo-400 font-medium">Testing connection...</span>
            )}
          </div>

          <button
            onClick={handleTestConnection}
            className="rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-indigo-600/30 hover:bg-indigo-500 transition-colors"
          >
            Test Connection
          </button>
        </div>
      </div>
    </div>
  );
};
