/**
 * Batch Queue Management Component
 */
import React from 'react';
import { ListOrdered, Play, Pause, Trash2, Download, RefreshCw, CheckCircle2, Clock } from 'lucide-react';
import { MediaItem } from '../types';

interface BatchQueueProps {
  items: MediaItem[];
  onRemoveItem: (id: string) => void;
  onClearCompleted: () => void;
  onStartBatch: () => void;
}

export const BatchQueue: React.FC<BatchQueueProps> = ({
  items,
  onRemoveItem,
  onClearCompleted,
  onStartBatch,
}) => {
  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 rounded-3xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ListOrdered className="h-6 w-6 text-amber-400" />
            <span>Batch Processing Queue</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">Manage multiple image and video upscale tasks in parallel</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onStartBatch}
            disabled={items.length === 0}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 transition-all"
          >
            <Play className="h-4 w-4" />
            <span>Start All Tasks</span>
          </button>
          <button
            onClick={onClearCompleted}
            className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 transition-colors"
          >
            <Trash2 className="h-4 w-4 text-rose-400" />
            <span>Clear Completed</span>
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-3xl border border-slate-800 bg-slate-950 p-16 text-center">
            <ListOrdered className="h-12 w-12 text-slate-600 mb-3" />
            <p className="text-base font-semibold text-white">Batch queue is currently empty</p>
            <p className="text-xs text-slate-500 mt-1">Add images or videos from the Image/Video upscaler studios to batch process them.</p>
          </div>
        ) : (
          items.map((item) => (
            <div
              key={item.id}
              className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 rounded-2xl border border-slate-800 bg-slate-900/80 p-4 backdrop-blur-sm"
            >
              <div className="flex items-center gap-4">
                <img
                  src={item.url}
                  alt={item.name}
                  className="h-14 w-14 rounded-xl object-cover border border-slate-700"
                />
                <div>
                  <h4 className="text-sm font-semibold text-white">{item.name}</h4>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                    <span className="capitalize px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">{item.type}</span>
                    <span>•</span>
                    <span>{item.originalWidth}x{item.originalHeight} → {item.targetWidth}x{item.targetHeight}</span>
                    <span>•</span>
                    <span className="text-indigo-400 font-semibold">{item.scale.toUpperCase()}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end">
                {/* Status Badge */}
                <div>
                  {item.status === 'completed' && (
                    <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-400 border border-emerald-500/20">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Completed
                    </span>
                  )}
                  {item.status === 'processing' && (
                    <span className="flex items-center gap-1.5 rounded-full bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-400 border border-indigo-500/20">
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                      Processing ({item.progress}%)
                    </span>
                  )}
                  {item.status === 'waiting' && (
                    <span className="flex items-center gap-1.5 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-400 border border-amber-500/20">
                      <Clock className="h-3.5 w-3.5" />
                      Waiting in Queue
                    </span>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {item.outputUrl && (
                    <a
                      href={item.outputUrl}
                      download={`upscaled_${item.name}`}
                      className="rounded-lg bg-emerald-600 p-2 text-white hover:bg-emerald-500 transition-colors"
                      title="Download"
                    >
                      <Download className="h-4 w-4" />
                    </a>
                  )}
                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="rounded-lg bg-slate-800 p-2 text-slate-400 hover:bg-rose-950 hover:text-rose-400 transition-colors"
                    title="Remove"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
