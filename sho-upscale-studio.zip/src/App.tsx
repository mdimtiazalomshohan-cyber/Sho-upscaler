/**
 * SHO Upscale Studio — Main App Component
 */
import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar, TabType } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { ImageUpscaler } from './components/ImageUpscaler';
import { VideoUpscaler } from './components/VideoUpscaler';
import { BatchQueue } from './components/BatchQueue';
import { HistoryView } from './components/HistoryView';
import { ModelsView } from './components/ModelsView';
import { ApiSettings } from './components/ApiSettings';
import { SettingsView } from './components/SettingsView';
import { HelpView } from './components/HelpView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { MediaItem, ProcessingMode, AppSettings } from './types';
import { aiEngine } from './services/aiEngine';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('dashboard');
  const [processingMode, setProcessingMode] = useState<ProcessingMode>('local');
  const [mobileOpen, setMobileOpen] = useState(false);

  const [batchItems, setBatchItems] = useState<MediaItem[]>([]);
  const [history, setHistory] = useState<MediaItem[]>([]);

  const [settings, setSettings] = useState<AppSettings>({
    theme: 'dark',
    language: 'English',
    defaultScale: '4x',
    defaultFormat: 'PNG',
    defaultQuality: 'high',
    processingMode: 'local',
    autoDownload: false,
    preserveMetadata: true,
    hardwareAcceleration: true,
    maxConcurrentJobs: 4,
  });

  const handleAddToBatch = (item: MediaItem) => {
    setBatchItems((prev) => [...prev, item]);
  };

  const handleRemoveBatchItem = (id: string) => {
    setBatchItems((prev) => prev.filter((i) => i.id !== id));
  };

  const handleClearBatchCompleted = () => {
    setBatchItems((prev) => prev.filter((i) => i.status !== 'completed'));
  };

  const handleStartBatch = async () => {
    const waitingItems = batchItems.filter((i) => i.status === 'waiting');
    if (waitingItems.length === 0) return;

    for (const item of waitingItems) {
      setBatchItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, status: 'processing', progress: 20 } : i))
      );

      try {
        if (item.type === 'image') {
          const res = await aiEngine.upscaleImage(item, item.quality, (p) => {
            setBatchItems((prev) =>
              prev.map((i) => (i.id === item.id ? { ...i, progress: p } : i))
            );
          });
          const completed: MediaItem = {
            ...item,
            status: 'completed',
            progress: 100,
            outputUrl: res.outputUrl,
            outputSize: res.outputSize,
            processingTime: res.processingTime,
          };
          setBatchItems((prev) => prev.map((i) => (i.id === item.id ? completed : i)));
          setHistory((prev) => [completed, ...prev]);
        } else {
          const res = await aiEngine.upscaleVideo(item, item.quality, (p) => {
            setBatchItems((prev) =>
              prev.map((i) => (i.id === item.id ? { ...i, progress: p } : i))
            );
          });
          const completed: MediaItem = {
            ...item,
            status: 'completed',
            progress: 100,
            outputUrl: res.outputUrl,
            outputSize: res.outputSize,
            processingTime: res.processingTime,
          };
          setBatchItems((prev) => prev.map((i) => (i.id === item.id ? completed : i)));
          setHistory((prev) => [completed, ...prev]);
        }
      } catch (err) {
        setBatchItems((prev) =>
          prev.map((i) => (i.id === item.id ? { ...i, status: 'failed' } : i))
        );
      }
    }
  };

  const handleSaveHistory = (item: MediaItem) => {
    setHistory((prev) => [item, ...prev]);
  };

  const activeJobsCount = batchItems.filter((i) => i.status === 'processing').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        processingMode={processingMode}
        setProcessingMode={setProcessingMode}
        activeJobsCount={activeJobsCount}
        onOpenBatch={() => setCurrentTab('batch')}
        onToggleMobileMenu={() => setMobileOpen(!mobileOpen)}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Navigation */}
        <Sidebar
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          batchCount={batchItems.length}
          mobileOpen={mobileOpen}
          onCloseMobile={() => setMobileOpen(false)}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-10">
          <div className="mx-auto max-w-7xl">
            {currentTab === 'dashboard' && (
              <Dashboard
                setCurrentTab={setCurrentTab}
                onUploadClick={() => setCurrentTab('image')}
                recentItems={history}
              />
            )}
            {currentTab === 'image' && (
              <ImageUpscaler
                processingMode={processingMode}
                onAddToBatch={handleAddToBatch}
                onSaveHistory={handleSaveHistory}
              />
            )}
            {currentTab === 'video' && (
              <VideoUpscaler
                processingMode={processingMode}
                onAddToBatch={handleAddToBatch}
                onSaveHistory={handleSaveHistory}
              />
            )}
            {currentTab === 'batch' && (
              <BatchQueue
                items={batchItems}
                onRemoveItem={handleRemoveBatchItem}
                onClearCompleted={handleClearBatchCompleted}
                onStartBatch={handleStartBatch}
              />
            )}
            {currentTab === 'history' && (
              <HistoryView history={history} onClearHistory={() => setHistory([])} />
            )}
            {currentTab === 'models' && <ModelsView />}
            {currentTab === 'api' && <ApiSettings />}
            {currentTab === 'settings' && <SettingsView settings={settings} setSettings={setSettings} />}
            {currentTab === 'help' && <HelpView />}
          </div>
        </main>
      </div>
      <OfflineIndicator />
    </div>
  );
}
