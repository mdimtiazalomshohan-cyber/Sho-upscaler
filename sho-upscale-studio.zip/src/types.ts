export type MediaType = 'image' | 'video';

export type ScaleFactor = '2x' | '4x' | '6x' | '8x';

export type TargetResolution = 'Original' | '1080p' | '1440p' | '2K' | '4K' | '6K' | '8K' | 'custom';

export type TaskStatus = 'waiting' | 'processing' | 'completed' | 'failed' | 'cancelled';

export type ProcessingMode = 'local' | 'cloud';

export type AiStrength = 'low' | 'medium' | 'high' | 'ultra';

export type DetailLevel = 'low' | 'medium' | 'high';

export type FilterLevel = 'off' | 'low' | 'medium' | 'high';

export type RestorationLevel = 'off' | 'auto' | 'strong';

export interface QualitySettings {
  aiStrength: AiStrength;
  detail: DetailLevel;
  noiseReduction: FilterLevel;
  sharpen: FilterLevel;
  faceRestoration: RestorationLevel;
  artifactRemoval: RestorationLevel;
  colorEnhancement: boolean;
  lowLightEnhancement: boolean;
  stockReady: boolean;
}

export interface MediaItem {
  id: string;
  name: string;
  type: MediaType;
  url: string;
  originalWidth: number;
  originalHeight: number;
  targetWidth: number;
  targetHeight: number;
  originalSize: number; // bytes
  outputSize?: number; // bytes
  scale: ScaleFactor;
  targetResolution: TargetResolution;
  customWidth?: number;
  customHeight?: number;
  quality: QualitySettings;
  status: TaskStatus;
  progress: number; // 0 to 100
  createdAt: number;
  outputUrl?: string;
  errorMessage?: string;
  processingTime?: number; // seconds
  fps?: number;
  duration?: number; // seconds
  codec?: string;
  bitrate?: string;
}

export interface HistoryItem {
  id: string;
  fileName: string;
  fileType: MediaType;
  originalRes: string;
  targetRes: string;
  mode: ProcessingMode;
  date: string;
  outputUrl: string;
  size: string;
  duration?: string;
}

export interface AiModelInfo {
  id: string;
  name: string;
  type: 'super-resolution' | 'face-restoration' | 'video-enhancement' | 'denoiser';
  description: string;
  speed: 'Fast' | 'Balanced' | 'High Quality';
  vram: string;
  supportedTypes: MediaType[];
  badge: string;
  status: 'Ready' | 'Downloading' | 'Not Downloaded';
}

export interface ApiConfig {
  provider: string;
  apiKey: string;
  endpoint: string;
  model: string;
  active: boolean;
  creditsRemaining?: number;
}

export interface AppSettings {
  theme: 'dark' | 'light' | 'midnight';
  language: string;
  defaultScale: ScaleFactor;
  defaultFormat: string;
  defaultQuality: AiStrength;
  processingMode: ProcessingMode;
  autoDownload: boolean;
  preserveMetadata: boolean;
  hardwareAcceleration: boolean;
  maxConcurrentJobs: number;
}
